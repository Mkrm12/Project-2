const fileUploadStates = new Map();  // Initialize fileUploadStates
const nodemailer = require('nodemailer');
const crypto = require('crypto');
const multer = require('multer');
const pdfParse = require('pdf-parse'); // Use pdfParse instead of PDFParser
const fs = require('fs');

const storage = multer.memoryStorage();  // Use memory storage for file uploads
const upload = multer({ storage: storage });

module.exports = function(app, forumData) {
    const bcrypt = require('bcrypt');
    const saltRounds = 10;
    const MIN_CREDIT_SCORE = 100;
    const MAX_CREDIT_SCORE = 1000;

    // Handle routes for the main pages
    // Home page route
    app.get('/',function(req,res){
        res.render('index.ejs', forumData)
    });

    // Handle user signup
    app.get('/signup',function(req,res){
        res.render('signup.ejs', forumData)
    });

    // Handle user signup with email verification
    app.post('/signup', function (req, res) {
    const { first_name, last_name, email, password } = req.body;

    // Generate a unique verification token
    const verificationToken = crypto.randomBytes(20).toString('hex');

    // Hash the password before storing it in the temporary table
    bcrypt.hash(password, saltRounds, function (err, hashedPassword) {
        if (err) {
            console.error('Error hashing password:', err);
            return res.status(500).send('Internal Server Error');
        }

        // Save the user data along with the verification token in a temporary table
        db.query(
            'INSERT INTO temp_users (first_name, last_name, email, password, verification_token) VALUES (?, ?, ?, ?, ?)',
            [first_name, last_name, email, hashedPassword, verificationToken],
            function (err, result) {
                if (err) {
                    console.error('Error inserting user into temp_users:', err);
                    return res.status(500).send('Internal Server Error');
                }

                // Send verification email
                sendVerificationEmail(email, verificationToken);

                console.log('Verification email sent successfully');
                res.redirect('/login'); // Redirect to login page after signup
            }
        );
    });
    });

    // Verification endpoint
    app.get('/verify/:token', function (req, res) {
    const token = req.params.token;

        // Find user by verification token in the temporary table
        db.query('SELECT * FROM temp_users WHERE verification_token = ?', [token], function (err, results) {
        if (err) {
            console.error('Error checking verification token:', err);
            return res.status(500).send('Internal Server Error');
        }

        if (results.length === 0) {
            return res.status(400).send('Invalid verification token');
        }
                db.query('UPDATE temp_users SET verification_token = NULL, verified = 1 WHERE verification_token = ?',[token], function (err, result) {
                    if (err) {
                        console.error('Error updating user verification status:', err);
                        return res.status(500).send('Internal Server Error');
                    }
                    console.log('User verified');
                    res.send('Verification successful. You can now log in.');
                    }
                );
            });
    });

    // Function to send verification email
    function sendVerificationEmail(toEmail, token) {
        const transporter = nodemailer.createTransport({
            service: 'gmail',
            auth: {
                user: 'areebshahzad0052@gmail.com', 
                pass: 'ovgi otlx eknk pqdg' 
            }
        });

        const mailOptions = {
            from: 'areebshahzad0052@gmail.com',
            to: toEmail,
            subject: 'Email Verification',
            text: `Click the following link to verify your email: http://localhost:8000/verify/${token}`
        };

        transporter.sendMail(mailOptions, function (error, info) {
            if (error) {
                console.error('Error sending verification email:', error);
            } else {
                console.log('Email sent:', info.response);
            }
        });
    }

    // Handle user login
    app.get('/login',function(req,res){
        res.render('login.ejs', forumData)
    });

   // Handle user login
    app.post('/login', function(req, res) {
    const { email, password } = req.body;

    // Check if email and password are provided
    if (!email || !password) {
        return res.status(400).render('login.ejs', { emailError: 'Email and password are required', passwordError: '' });
    }

    // Check if email exists in the database
    db.query('SELECT user_id, password, verified FROM temp_users WHERE email = ?', [email], function(err, results) {
        if (err) {
            console.error('Error checking email:', err);
            return res.status(500).send('Internal Server Error');
        }

        // If email does not exist, set error message
        if (results.length === 0) {
            return res.status(400).render('login.ejs', { emailError: 'Email not registered', passwordError: '' });
        }

        const user = results[0];

        // Check if the user is verified
        if (!user.verified) {
            return res.status(400).render('login.ejs', { emailError: 'Email not verified. Check your email for the verification link.', passwordError: '' });
        }

        // Check if the provided password matches the hashed password in the database
        bcrypt.compare(password, user.password, function(err, passwordMatch) {
            if (err) {
                console.error('Error comparing passwords:', err);
                return res.status(500).send('Internal Server Error');
            }

            // If passwords match, login successful
            if (passwordMatch) {
                // Use user.user_id for further processing or storing in session
                const userId = user.user_id;
                req.session.userId = userId; // Store user ID in the session
                

                // You can redirect the user to a dashboard or home page
                res.render('dashboard.ejs');
            } else {
                // If passwords don't match, set error message
                res.status(400).render('login.ejs', { emailError: '', passwordError: 'Incorrect Email or Password' });
            }
        });
    });
    });


    // Handle GET request for the forgot-password page
    app.get('/forgot-password',function(req,res){
        res.render('forgot-password.ejs', forumData)
    });

    // Handle POST request for forgot-password
    app.post('/forgot-password', function (req, res) {
    const { email } = req.body;

    // Check if email exists in the users table
    db.query('SELECT * FROM temp_users WHERE email = ?', [email], function (err, results) {
        if (err) {
            console.error('Error checking email for forgot password:', err);
            return res.status(500).send('Internal Server Error');
        }

        if (results.length === 0) {
            return res.status(400).send('Email not found');
        }

        // Generate a unique verification token
        const verificationToken = crypto.randomBytes(20).toString('hex');

        // Save the verification token in the database
        db.query(
            'UPDATE temp_users SET verification_token = ? WHERE email = ?',
            [verificationToken, email],
            function (err, result) {
                if (err) {
                    console.error('Error updating verification token:', err);
                    return res.status(500).send('Internal Server Error');
                }

                // Send email with password reset link
                sendPasswordResetEmail(email, verificationToken);

                console.log('Password reset email sent successfully');
                res.send('Password reset email sent. Check your email for instructions.');
            }
        );
       });
    });

    // Function to send password reset email
    function sendPasswordResetEmail(toEmail, token) {
    const resetLink = `http://localhost:8000/reset-password/${token}`;

    const transporter = nodemailer.createTransport({
        service: 'gmail',
        auth: {
            user: 'areebshahzad0052@gmail.com',
            pass: 'ovgi otlx eknk pqdg'
        }
    });

    const mailOptions = {
        from: 'areebshahzad0052@gmail.com',
        to: toEmail,
        subject: 'Password Reset',
        text: `Click the following link to reset your password: http://localhost:8000/reset-password/${token}`
    };


    transporter.sendMail(mailOptions, function (error, info) {
        if (error) {
            console.error('Error sending password reset email:', error);
        } else {
            console.log('Password reset email sent:', info.response);
        }
    });
    }

    // Handle GET request for reset-password
    app.get('/reset-password/:token', function (req, res) {
        const token = req.params.token;
        console.log('Token from URL:', token);

    // Render the reset-password.ejs page with the token
    res.render('reset-password.ejs', { token });
    });

    // Handle POST request for reset-password
    app.post('/reset-password', function (req, res) {
    const token = req.body.token;  // Retrieve the token from the form submission
    const { newPassword, confirmNewPassword } = req.body;

    // Find user by verification token
    db.query('SELECT * FROM temp_users WHERE verification_token = ?', [token], function (err, results) {
        if (err) {
            console.error('Error checking verification token for password reset:', err);
            return res.status(500).send('Internal Server Error');
        }

        if (results.length === 0) {
            return res.status(400).send('Invalid verification token');
        }

        const user = results[0];

        // Check if passwords match
        if (newPassword !== confirmNewPassword) {
            return res.status(400).send('Passwords do not match');
        }

        // Hash the new password
        bcrypt.hash(newPassword, saltRounds, function (err, hashedPassword) {
            if (err) {
                console.error('Error hashing new password:', err);
                return res.status(500).send('Internal Server Error');
            }

            // Update user password and clear verification token
            db.query(
                'UPDATE temp_users SET password = ?, verification_token = NULL WHERE user_id = ?',
                [hashedPassword, user.user_id],
                function (err, result) {
                    if (err) {
                        console.error('Error updating user password:', err);
                        return res.status(500).send('Internal Server Error');
                    }

                    console.log('Password reset successful');
                    res.send('Password reset successful. You can now log in.');
                }
            );
          });
        });
    });

    


    app.get('/activate-account', function(req, res) {
        const userId = req.session.userId; // Obtain user ID from the session
    
        // Check eligibility status in the database
        db.query('SELECT eligible FROM temp_users WHERE user_id = ?', [userId], function(err, results) {
            if (err) {
                console.error('Error checking eligibility status:', err);
                return res.status(500).send('Internal Server Error');
            }
    
            const user = results[0];
    
            if (!user) {
                // User not found, handle accordingly
                return res.status(400).send('User not found');
            }
    
            if (user.eligible === 0) {
                console.log("working")
                // Eligibility is 0, redirect to activate my account page
                return res.render('activate-account.ejs');
            } else {
                // Eligibility is 1, render the package page
                res.render('initialpackage.ejs');
            }
        });
    });

   // Handle file upload
app.post('/upload-pdf', upload.single('pdfFile'), function (req, res) {
    // Process the uploaded file

    // Check if a file has already been uploaded for this user
    const userId = req.session.userId; /* Obtain user ID (you may use session or other authentication mechanism) */;
    // if (fileUploadStates.get(userId)) {
    //     // User has already uploaded a file, handle accordingly (e.g., show an error message)
    //     return res.render('activate-account.ejs', { fileUploaded: false, alreadyUploaded: true });
    // }

    if (req.file) {
        // Generate a random credit score
        const creditScore = Math.floor(Math.random() * (MAX_CREDIT_SCORE - MIN_CREDIT_SCORE + 1)) + MIN_CREDIT_SCORE;
        console.log("Credit Score:", creditScore);

        // Set file upload state to true for this user
      // fileUploadStates.set(userId, true);

        // Calculate eligibility based on credit score
        let eligibilityMessage = '';

        //Check eligibility based on credit score
        if (creditScore >= 100 && creditScore <= 500) {
            eligibilityMessage = "We're sorry, you are not eligible.";
        } else if (creditScore > 500 && creditScore <= 1000) {
            eligibilityMessage = "Congratulations, you are eligible.";
        
            // Update user eligibility
              db.query(
                'UPDATE temp_users SET eligible = 1 WHERE user_id = ?',
                [userId],
                function (err, result) {
                    if (err) {
                        console.error('Error updating user eligibility:', err);
                        return res.status(500).send('Internal Server Error');
                    }

                    console.log('Eligibility updated');
                    // Render the activate-account page with file upload success message and credit score
                    //res.render('activate-account.ejs', { fileUploaded: true, alreadyUploaded: false, eligibilityMessage: eligibilityMessage || '' });
                    res.render('initialpackage.ejs');
                }
            );
            return; // Return to avoid rendering the page multiple times
        }

        // Render the activate-account page with file upload success message and credit score
        res.render('activate-account.ejs', { fileUploaded: true, alreadyUploaded: false, eligibilityMessage: eligibilityMessage || '' });
    }
});



 
    // // Handle file upload
    // app.post('/upload-pdf', upload.single('pdfFile'), function(req, res) {
    // // Process the uploaded file
    // const { buffer } = req.file;

    // // Generate a random credit score
    // const creditScore = Math.floor(Math.random() * (MAX_CREDIT_SCORE - MIN_CREDIT_SCORE + 1)) + MIN_CREDIT_SCORE;
    // console.log('Generated Credit Score:', creditScore);
    // // Render the activate-account page with file upload success message and credit score
    // res.render('activate-account.ejs', { fileUploaded: true});
    // });
    

    // app.post('/upload-pdf', upload.single('pdfFile'), function(req, res) {
    //     const { buffer } = req.file;
    
    //     // Use pdfParse function directly instead of PDFParser constructor
    //     pdfParse(buffer).then(data => {
    //         const pdfTextContent = data.text;
    
    //         // Use regular expression to find occurrences of "credit score" in the PDF content
    //         const specificWord = 'credit score';
    //         const regex = new RegExp(specificWord, 'gi');
    //         const matches = pdfTextContent.match(regex);
    
    //         if (matches) {
    //             console.log(`Occurrences of "${specificWord}":`, matches);
    //             res.send(`Occurrences of "${specificWord}":\n${matches.join('\n')}`);
    //         } else {
    //             console.log(`The specific word "${specificWord}" was not found in the PDF.`);
    //             res.send(`The specific word "${specificWord}" was not found in the PDF.`);
    //         }
    //     }).catch(error => {
    //         console.error('Error parsing PDF:', error);
    //         return res.status(500).send('Error parsing PDF');
    //     });
    // });

 
};