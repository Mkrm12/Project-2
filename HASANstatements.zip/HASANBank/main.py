# This file is the entry point of the application. It creates an instance of HASANBank,
# adds transactions, and requests a statement.

from bank.hasan_bank import HASANBank

def main():
    bank = HASANBank()
    bank.add_transaction("03/15/2024", 100, "Deposit")
    bank.add_transaction("03/20/2024", -50, "Withdrawal")
    bank.add_transaction("04/01/2024", 200, "Deposit")
    
    # Request a statement for March 2024
    bank.get_statement(3, 2024)

if __name__ == "__main__":
    main()
