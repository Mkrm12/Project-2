# This file contains the definition of the HASANBank class.

class HASANBank:
    def __init__(self):
        self.transactions = []

    def add_transaction(self, date, amount, description):
        self.transactions.append((date, amount, description))

    def get_statement(self, month, year):
        print(f"Bank Statement for {month}/{year}")
        print("Date       | Amount | Description")
        print("-----------------------------------")
        total_amount = 0
        for date, amount, description in self.transactions:
            trans_month, trans_year = int(date.split('/')[0]), int(date.split('/')[2])
            if trans_month == month and trans_year == year:
                print(f"{date} | ${amount:.2f} | {description}")
                total_amount += amount
        print("-----------------------------------")
        print(f"Total amount for {month}/{year}: ${total_amount:.2f}")
