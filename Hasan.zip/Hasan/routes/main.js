const nodemailer = require('nodemailer');
const crypto = require('crypto');

module.exports = function(app, forumData) {
    const bcrypt = require('bcrypt');
    const saltRounds = 10;

    // Handle routes for the main pages
    // Home page route
    app.get('/',function(req,res){
        res.render('index.ejs', forumData)
    });

    // Handle user signup
    app.get('/signup',function(req,res){
        res.render('signup.ejs', forumData)
    });

    // Handle user signup with email verification
    app.post('/signup', function (req, res) {
    const { first_name, last_name, email, password } = req.body;

    // Generate a unique verification token
    const verificationToken = crypto.randomBytes(20).toString('hex');

    // Hash the password before storing it in the temporary table
    bcrypt.hash(password, saltRounds, function (err, hashedPassword) {
        if (err) {
            console.error('Error hashing password:', err);
            return res.status(500).send('Internal Server Error');
        }

        // Save the user data along with the verification token in a temporary table
        db.query(
            'INSERT INTO temp_users (first_name, last_name, email, password, verification_token) VALUES (?, ?, ?, ?, ?)',
            [first_name, last_name, email, hashedPassword, verificationToken],
            function (err, result) {
                if (err) {
                    console.error('Error inserting user into temp_users:', err);
                    return res.status(500).send('Internal Server Error');
                }

                // Send verification email
                sendVerificationEmail(email, verificationToken);

                console.log('Verification email sent successfully');
                res.redirect('/login'); // Redirect to login page after signup
            }
        );
    });
    });

    // Verification endpoint
    app.get('/verify/:token', function (req, res) {
    const token = req.params.token;

        // Find user by verification token in the temporary table
        db.query('SELECT * FROM temp_users WHERE verification_token = ?', [token], function (err, results) {
        if (err) {
            console.error('Error checking verification token:', err);
            return res.status(500).send('Internal Server Error');
        }

        if (results.length === 0) {
            return res.status(400).send('Invalid verification token');
        }

        // Move user data from temporary table to actual users table
        const user = results[0];
        db.query('INSERT INTO users (first_name, last_name, email, password) VALUES (?, ?, ?, ?)',
            [user.first_name, user.last_name, user.email, user.password],
            function (err, result) {
                if (err) {
                    console.error('Error moving user data to users table:', err);
                    return res.status(500).send('Internal Server Error');
                }

                // Update user status to verified
                const userId = result.insertId;
                db.query('UPDATE users SET verification_token = NULL, verified = 1 WHERE user_id = ?',[userId], function (err, result) {
                    if (err) {
                        console.error('Error updating user verification status:', err);
                        return res.status(500).send('Internal Server Error');
                    }
                    console.log('User verified and data moved successfully');
                    res.send('Verification successful. You can now log in.');
                    }
                );
            });
        });
    });

    // Function to send verification email
    function sendVerificationEmail(toEmail, token) {
        const transporter = nodemailer.createTransport({
            service: 'gmail',
            auth: {
                user: 'areebshahzad0052@gmail.com', 
                pass: 'ovgi otlx eknk pqdg' 
            }
        });

        const mailOptions = {
            from: 'areebshahzad0052@gmail.com',
            to: toEmail,
            subject: 'Email Verification',
            text: `Click the following link to verify your email: http://localhost:8000/verify/${token}`
        };

        transporter.sendMail(mailOptions, function (error, info) {
            if (error) {
                console.error('Error sending verification email:', error);
            } else {
                console.log('Email sent:', info.response);
            }
        });
    }

    // Handle user login
    app.get('/login',function(req,res){
        res.render('login.ejs', forumData)
    });

    // Handle user login
    app.post('/login', function(req, res) {
    const { email, password } = req.body;

    // Check if email and password are provided
    if (!email || !password) {
        return res.status(400).render('login.ejs', { emailError: 'Email and password are required', passwordError: '' });
    }

    // Check if email exists in the database
        db.query('SELECT * FROM users WHERE email = ?', [email], function(err, results) {
        if (err) {
            console.error('Error checking email:', err);
            return res.status(500).send('Internal Server Error');
        }

        // If email does not exist, set error message
        if (results.length === 0) {
            return res.status(400).render('login.ejs', { emailError: 'Email not registered', passwordError: '' });
        }

        const user = results[0];

        // Check if the provided password matches the hashed password in the database
        bcrypt.compare(password, user.password, function(err, passwordMatch) {
            console.log('Password Match:', passwordMatch);
            if (err) {
                console.error('Error comparing passwords:', err);
                return res.status(500).send('Internal Server Error');
            }

            // If passwords match, login successful
            if (passwordMatch) {
                // You can redirect the user to a dashboard or home page
                res.send('Login successful');
                
            } else {
                // If passwords don't match, set error message
                res.status(400).render('login.ejs', { emailError: '', passwordError: 'Incorrect Email or Password' });
            }
           });
       });
    });

    // Handle GET request for the forgot-password page
    app.get('/forgot-password',function(req,res){
        res.render('forgot-password.ejs', forumData)
    });

    // Handle POST request for forgot-password
    app.post('/forgot-password', function (req, res) {
    const { email } = req.body;

    // Check if email exists in the users table
    db.query('SELECT * FROM users WHERE email = ?', [email], function (err, results) {
        if (err) {
            console.error('Error checking email for forgot password:', err);
            return res.status(500).send('Internal Server Error');
        }

        if (results.length === 0) {
            return res.status(400).send('Email not found');
        }

        // Generate a unique verification token
        const verificationToken = crypto.randomBytes(20).toString('hex');

        // Save the verification token in the database
        db.query(
            'UPDATE users SET verification_token = ? WHERE email = ?',
            [verificationToken, email],
            function (err, result) {
                console.log('Update result:', result);
                if (err) {
                    console.error('Error updating verification token:', err);
                    return res.status(500).send('Internal Server Error');
                }

                // Send email with password reset link
                sendPasswordResetEmail(email, verificationToken);

                console.log('Password reset email sent successfully');
                res.send('Password reset email sent. Check your email for instructions.');
            }
        );
       });
    });

    // Function to send password reset email
    function sendPasswordResetEmail(toEmail, token) {
    const resetLink = `http://localhost:8000/reset-password/${token}`;

    const transporter = nodemailer.createTransport({
        service: 'gmail',
        auth: {
            user: 'areebshahzad0052@gmail.com',
            pass: 'ovgi otlx eknk pqdg'
        }
    });

    const mailOptions = {
        from: 'areebshahzad0052@gmail.com',
        to: toEmail,
        subject: 'Password Reset',
        text: `Click the following link to reset your password: http://localhost:8000/reset-password/${token}`
    };


    transporter.sendMail(mailOptions, function (error, info) {
        if (error) {
            console.error('Error sending password reset email:', error);
        } else {
            console.log('Password reset email sent:', info.response);
        }
    });
    }

    // Handle GET request for reset-password
    app.get('/reset-password/:token', function (req, res) {
        const token = req.params.token;
        console.log('Token from URL:', token);

    // Render the reset-password.ejs page with the token
    res.render('reset-password.ejs', { token });
    });

    // Handle POST request for reset-password
    app.post('/reset-password', function (req, res) {
    const token = req.body.token;  // Retrieve the token from the form submission
    const { newPassword, confirmNewPassword } = req.body;

    // Find user by verification token
    db.query('SELECT * FROM users WHERE verification_token = ?', [token], function (err, results) {
        if (err) {
            console.error('Error checking verification token for password reset:', err);
            return res.status(500).send('Internal Server Error');
        }

        if (results.length === 0) {
            return res.status(400).send('Invalid verification token');
        }

        const user = results[0];

        // Check if passwords match
        if (newPassword !== confirmNewPassword) {
            return res.status(400).send('Passwords do not match');
        }

        // Hash the new password
        bcrypt.hash(newPassword, saltRounds, function (err, hashedPassword) {
            if (err) {
                console.error('Error hashing new password:', err);
                return res.status(500).send('Internal Server Error');
            }

            // Update user password and clear verification token
            db.query(
                'UPDATE users SET password = ?, verification_token = NULL WHERE user_id = ?',
                [hashedPassword, user.user_id],
                function (err, result) {
                    if (err) {
                        console.error('Error updating user password:', err);
                        return res.status(500).send('Internal Server Error');
                    }

                    console.log('Password reset successful');
                    res.send('Password reset successful. You can now log in.');
                }
            );
          });
        });
    });

};
