// Import the modules we need
var mysql = require('mysql');
var express = require('express')
var ejs = require('ejs')
var bodyParser = require('body-parser')
const session = require('express-session');

// Define the database connection
const db = mysql.createConnection({
    host: 'localhost',
    user: 'appuser',
    password: 'app2027',
    database: 'hasan'
});

// Connect to the database
db.connect((err) => {
    if (err) {
        throw err;
    }
    console.log('Connected to database');
});
global.db = db;

// Create the express application object
const app = express()
const port = 8000
app.use(bodyParser.urlencoded({
    extended: true
}))

// Set up css
app.use(express.static(__dirname + '/public'));

app.set("views", __dirname + "/views");
app.set("view engine", "ejs");
app.engine("html", ejs.renderFile);

app.use(express.urlencoded({ extended: true }));

// session , to keep track of their id 
app.use(session({
  secret: 'secret',
  resave: true,
  saveUninitialized: true,
}));

// Define our data
var forumData = {
  forumName: "hasan"
}

// When a user signs up
app.post('/signup', (req, res) => {
    const userId = req.body.userId;
    const annualSalary = Math.random() * (10000 - 500) + 500; // Generate a random annual salary between £500 and £10k
    db.query('INSERT INTO salaries (user_id, annual_salary) VALUES (?, ?)', [userId, annualSalary], function (error, results, fields) {
        if (error) throw error;
        // User signed up and salary inserted
        res.redirect('/packages'); // Redirect to the packages page
    });
});

// When a user selects a package
app.post('/select-package', (req, res) => {
    const userId = req.body.userId;
    const packageId = req.body.packageId;
    db.query('SELECT COUNT(*) AS count FROM user_packages WHERE package_id = ? GROUP BY group_number ORDER BY group_number', [packageId], function (error, results, fields) {
        if (error) throw error;
        let groupNumber = 1;
        for (let result of results) {
            if (result.count < 10) break;
            groupNumber++;
        }
        db.query('INSERT INTO user_packages (user_id, package_id, group_number) VALUES (?, ?, ?)', [userId, packageId, groupNumber], function (error, results, fields) {
            if (error) throw error;
            // User selected package and assigned to group
            res.redirect('/dashboard'); // Redirect to the dashboard page
        });
    });
});

// Requires the main.js file inside the routes folder passing in the Express app and data as arguments.  All the routes will go in this file
require("./routes/main")(app, forumData);

app.listen(port, () => console.log(`App listening on port ${port}!`));
