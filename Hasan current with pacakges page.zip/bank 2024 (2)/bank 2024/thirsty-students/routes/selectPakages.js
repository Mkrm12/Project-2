// function selectPackage(amount, length, monthlyPayment) {
//     // Update the current package display
//     document.querySelector('.current-package').innerHTML = `
//         <h2>Your Current Active Package</h2>
//         <p>Amount: £${amount}</p>
//         <p>Length: ${length}</p>
//         <p>Monthly Payment: £${monthlyPayment}</p>
//     `;

//     // Send the package data to the server to update the database
//     fetch('/update-package', {
//         method: 'POST',
//         headers: {
//             'Content-Type': 'application/json',
//         },
//         body: JSON.stringify({
//             userId: 1,  // Replace this with the actual user ID
//             amount: amount,
//             length: length,
//             monthlyPayment: monthlyPayment,
//         }),
//     });
// }
