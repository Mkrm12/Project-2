const nodemailer = require('nodemailer');
const crypto = require('crypto');

module.exports = function(app, forumData) {
    const bcrypt = require('bcrypt');
    const saltRounds = 10;

app.get("/", (req, res) => {
    res.render("index.ejs");
  });
  
  app.get("/how-It-works", (req, res) => {
    res.render("howItworks.ejs");
  });
  app.get("/contact", (req, res) => {
    res.render("contactUs.ejs");
  });
  
  app.get("/register", (req, res) => {
    res.render("register.ejs");
  });
  app.get("/login", (req, res) => {
    res.render("login.ejs");
  });

  app.get("/forgot-password", (req, res) => {
    res.render("forgot-password.ejs");
  });

  //packages
  app.get("/change-package", (req, res) => {
    res.render("packages.ejs");
});
// Handle GET request for reset-password
app.get('/reset-password/:token', function (req, res) {
    const token = req.params.token;
    console.log('Token from URL:', token);

// Render the reset-password.ejs page with the token
res.render('reset-password.ejs', { token });
});
  
  app.get("/dashboard", (req, res) => {
    res.render("dashboard.ejs");
  });
  
  app.post("/register", (req, res) => {
    const { first_name, last_name, email, password } = req.body;

    // Generate a unique verification token
    const verificationToken = crypto.randomBytes(20).toString('hex');

    // Hash the password before storing it in the temporary table
    bcrypt.hash(password, saltRounds, function (err, hashedPassword) {
        if (err) {
            console.error('Error hashing password:', err);
            return res.status(500).send('Internal Server Error');
        }
      

        // Save the user data along with the verification token in a temporary table
        db.query(
            'INSERT INTO temp_users (first_name, last_name, email, password, verification_token) VALUES (?, ?, ?, ?, ?)',
            [first_name, last_name, email, hashedPassword, verificationToken],
            function (err, result) {
                if (err) {
                    console.error('Error inserting user into temp_users:', err);
                    return res.status(500).send('Internal Server Error');
                }

                // Send verification email
                sendVerificationEmail(email, verificationToken);

                console.log('Verification email sent successfully');
                res.redirect('/login'); // Redirect to login page after signup
            }
        );
    });
    });

    // Verification endpoint
    app.get('/verify/:token', function (req, res) {
    const token = req.params.token;

        // Find user by verification token in the temporary table
        db.query('SELECT * FROM temp_users WHERE verification_token = ?', [token], function (err, results) {
        if (err) {
            console.error('Error checking verification token:', err);
            return res.status(500).send('Internal Server Error');
        }

        if (results.length === 0) {
            return res.status(400).send('Invalid verification token');
        }

        // Move user data from temporary table to actual users table
        const user = results[0];
        



        // Generate a random number between 500 and 10000 for yearly salary
        const yearly_Salary = Math.floor(Math.random() * (10000 - 500 + 1)) + 500;
        const monthly_Salary = Math.floor(yearly_Salary / 12);

        // Update the selectPackage function to store the package id
function selectPackage(id, name, amount, length, monthlyPayment) {
    activePackage = {id, name, amount, length, monthlyPayment };
    updateCurrentPackage();
}

// Update the user registration code
db.query('INSERT INTO users (first_name, last_name, email, password, Membership, monthly_Salary, yearly_Salary, package_id, group_id) VALUES (?, ?, ?, ?, 1000, ?, ?, ?, ?)',
    [user.first_name, user.last_name, user.email, user.password,  monthly_Salary, yearly_Salary, activePackage.id, groupId],
    function (err, result) {
    if (err) {
        console.error('Error moving user data to users table:', err);
        return res.status(500).send('Internal Server Error');
    }





        

                // Update user status to verified
                const userId = result.insertId;
                db.query('UPDATE users SET verification_token = NULL, verified = 1 WHERE user_id = ?',[userId], function (err, result) {
                    if (err) {
                        console.error('Error updating user verification status:', err);
                        return res.status(500).send('Internal Server Error');
                    }
                    console.log('User verified and data moved successfully');
                    res.send('Verification successful. You can now log in.');
                    }
                );
            });
        });
    });

    // Function to send verification email
    function sendVerificationEmail(toEmail, token) {
        const transporter = nodemailer.createTransport({
            service: 'gmail',
            auth: {
                user: 'areebshahzad0052@gmail.com', 
                pass: 'ovgi otlx eknk pqdg' 
            }
        });

        const mailOptions = {
            from: 'areebshahzad0052@gmail.com',
            to: toEmail,
            subject: 'Email Verification',
            text: `Click the following link to verify your email: http://localhost:8000/verify/${token}`
        };

        transporter.sendMail(mailOptions, function (error, info) {
            if (error) {
                console.error('Error sending verification email:', error);
            } else {
                console.log('Email sent:', info.response);
            }
        });
    }

    // Login 

    app.post('/login', (req, res) => {
        const { email, password } = req.body;
    
        // Check if email and password are provided
        if (!email || !password) {
            return res.status(400).render('login.ejs', { emailError: 'Email and password are required', passwordError: '' });
        }
    
        // Check if email exists in the database
            db.query('SELECT * FROM users WHERE email = ?', [email], function(err, results) {
            if (err) {
                console.error('Error checking email:', err);
                return res.status(500).send('Internal Server Error');
            }
    
            // If email does not exist, set error message
            if (results.length === 0) {
                return res.status(400).render('login.ejs', { emailError: 'Email not registered', passwordError: '' });
            }
    
            const user = results[0];
    
            // Check if the provided password matches the hashed password in the database
            bcrypt.compare(password, user.password, function(err, passwordMatch) {
                console.log('Password Match:', passwordMatch);
                if (err) {
                    console.error('Error comparing passwords:', err);
                    return res.status(500).send('Internal Server Error');
                }
    
                // If passwords match, login successful
                if (passwordMatch) {
                    
                   // Store user ID in the session
                req.session.userID = user.user_id; 

                // Log the user ID to the console
                console.log('User ID:', req.session.userID);
                    res.render('dashboard.ejs');
                    
                } else {
                    // If passwords don't match, set error message
                    res.status(400).render('login.ejs', { emailError: '', passwordError: 'Incorrect Email or Password' });
                }
               });
           });
      });
      app.get('/logout', (req, res) => {
        req.session.destroy((err) => {
          if (err) {
            console.error('Error destroying session:', err);
          }
          res.redirect('/');
        });
      });

      
    // Handle POST request for forgot-password
    app.post('/forgot-password', function (req, res) {
        const { email } = req.body;
    
        // Check if email exists in the users table
        db.query('SELECT * FROM users WHERE email = ?', [email], function (err, results) {
            if (err) {
                console.error('Error checking email for forgot password:', err);
                return res.status(500).send('Internal Server Error');
            }
    
            if (results.length === 0) {
                return res.status(400).send('Email not found');
            }
    
            // Generate a unique verification token
            const verificationToken = crypto.randomBytes(20).toString('hex');
    
            // Save the verification token in the database
            db.query(
                'UPDATE users SET verification_token = ? WHERE email = ?',
                [verificationToken, email],
                function (err, result) {
                    console.log('Update result:', result);
                    if (err) {
                        console.error('Error updating verification token:', err);
                        return res.status(500).send('Internal Server Error');
                    }
    
                    // Send email with password reset link
                    sendPasswordResetEmail(email, verificationToken);
    
                    console.log('Password reset email sent successfully');
                    res.send('Password reset email sent. Check your email for instructions.');
                }
            );
           });
        });
    
        // Function to send password reset email
        function sendPasswordResetEmail(toEmail, token) {
        const resetLink = `http://localhost:8000/reset-password/${token}`;
    
        const transporter = nodemailer.createTransport({
            service: 'gmail',
            auth: {
                user: 'areebshahzad0052@gmail.com',
                pass: 'ovgi otlx eknk pqdg'
            }
        });
    
        const mailOptions = {
            from: 'areebshahzad0052@gmail.com',
            to: toEmail,
            subject: 'Password Reset',
            text: `Click the following link to reset your password: http://localhost:8000/reset-password/${token}`
        };
    
    
        transporter.sendMail(mailOptions, function (error, info) {
            if (error) {
                console.error('Error sending password reset email:', error);
            } else {
                console.log('Password reset email sent:', info.response);
            }
        });
        }

        

    // Handle POST request for reset-password
    app.post('/reset-password', function (req, res) {
        const token = req.body.token;  // Retrieve the token from the form submission
        const { newPassword, confirmNewPassword } = req.body;
    
        // Find user by verification token
        db.query('SELECT * FROM users WHERE verification_token = ?', [token], function (err, results) {
            if (err) {
                console.error('Error checking verification token for password reset:', err);
                return res.status(500).send('Internal Server Error');
            }
    
            if (results.length === 0) {
                return res.status(400).send('Invalid verification token');
            }
    
            const user = results[0];
    
            // Check if passwords match
            if (newPassword !== confirmNewPassword) {
                return res.status(400).send('Passwords do not match');
            }

            // Check if newPassword is not empty
            if (!newPassword) {
                return res.status(400).send('New password cannot be empty');
            }
    
            // Hash the new password
            bcrypt.hash(newPassword, saltRounds, function (err, hashedPassword) {
                if (err) {
                    console.error('Error hashing new password:', err);
                    return res.status(500).send('Internal Server Error');
                }
    
                // Update user password and clear verification token
                db.query(
                    'UPDATE users SET password = ?, verification_token = NULL WHERE user_id = ?',
                    [hashedPassword, user.user_id],
            
                    function (err, result) {
                        if (err) {
                            console.error("Problem updating database")
                            console.error('Error updating user password:', err);
                            return res.status(500).send('Internal Server Error');
                        }
    
                        console.log('Password reset successful');
                        res.send('Password reset successful. You can now log in.');
                    }
                );
              });
            });
        });
// Display start or start-info based on user's isActive status
app.get('/start', function (req, res) {
    const userId = req.session.userID;

    // Check if the user is active
    db.query('SELECT IsActive FROM users WHERE user_id = ?', [userId], (error, result) => {
        if (error) {
            console.error('Error checking user status:', error);
            return res.status(500).json({ message: 'Internal Server Error' });
        }

        const isActive = result[0] ? result[0].IsActive : null;
        console.log(isActive)
        if (isActive === 0) {
            // User is not active, render start.ejs
            res.render('start.ejs');
        } else if (isActive === 1) {
            // User is active, render start-info.ejs
            const sqlquery = `
                SELECT
                GroupID as id,
                Membership as name,
                MemberCount as memberCount
            FROM GroupMem;
            
            `;
            db.query(sqlquery, [userId], (error, result) => {
                if (error) {
                    console.error('Error fetching user-related group data:', error);
                    return res.status(500).json({ message: 'Internal Server Error' });
                }

                const userData = result[0];

                if (!userData) {
                    return res.status(404).json({ message: 'User not found in any group' });
                }

                // Render start-info.ejs with relevant user-related data
                res.render('start-info.ejs', { userData });
            });
        } else {
            // Handle other cases if needed
            return res.status(404).json({ message: 'User status unknown' });
        }
    });
});


    
      
          app.post('/start-saving', (req, res) => {
            const userId = req.session.userID;
        
            if (!userId) {
                return res.status(401).json({ message: 'Unauthorized' });
            }
        
            db.query('SELECT * FROM users WHERE user_id = ?', [userId], (err, results) => {
                if (err) {
                    console.error('Error retrieving user details:', err);
                    return res.status(500).json({ message: 'Internal Server Error' });
                }
        
                if (results.length === 0) {
                    return res.status(404).json({ message: 'User not found' });
                }
        
                const user = results[0];
        
                // Retrieve user details
    db.query('SELECT * FROM users WHERE user_id = ?', [userId], (err, results) => {
        if (err) {
            console.error('Error retrieving user details:', err);
            return res.status(500).json({ message: 'Internal Server Error' });
        }

        if (results.length === 0) {
            return res.status(404).json({ message: 'User not found' });
        }

        const user = results[0];

        // Check if the user is not active
        if (user.IsActive === 0) {
            // Find a group with IsActive = 0, matching membership, and MemberCount < 3
            db.query('SELECT * FROM GroupMem WHERE IsActive = 0 AND Membership = ? AND MemberCount < 3 LIMIT 1', [user.Membership], (err, groupResults) => {
                if (err) {
                    console.error('Error checking available groups:', err);
                    return res.status(500).json({ message: 'Internal Server Error' });
                }

                if (groupResults.length === 0) {
                    // No available groups, create a new group
                    db.query('INSERT INTO GroupMem (Membership, IsActive, MemberCount) VALUES (?, 0, 1)', [user.Membership], (err, insertResult) => {
                        if (err) {
                            console.error('Error creating a new group:', err);
                            return res.status(500).json({ message: 'Internal Server Error' });
                        }

                        const newGroupId = insertResult.insertId;

                        // Update user details with the new group ID
                        db.query('UPDATE users SET IsActive = 1, GroupID = ? WHERE user_id = ?', [newGroupId, userId], (err, updateResult) => {
                            if (err) {
                                console.error('Error updating user details with a new group:', err);
                                return res.status(500).json({ message: 'Internal Server Error' });
                            }

                            return res.status(200).json({ message: 'User added to a new group' });
                        });
                    });
                } else {
                    // Found an available group, add user to the group
                    const availableGroupId = groupResults[0].GroupID;

                    // Update user details with the available group ID
                    db.query('UPDATE users SET IsActive = 1, GroupID = ? WHERE user_id = ?', [availableGroupId, userId], (err, updateResult) => {
                        if (err) {
                            console.error('Error updating user details with an available group:', err);
                            return res.status(500).json({ message: 'Internal Server Error' });
                        }

                        // Update MemberCount in GroupMem
                        db.query('UPDATE GroupMem SET MemberCount = MemberCount + 1 WHERE GroupID = ?', [availableGroupId], (err, groupUpdateResult) => {
                            if (err) {
                                console.error('Error updating group member count:', err);
                                return res.status(500).json({ message: 'Internal Server Error' });
                            }

                                                    // Check if the group is now full
                            console.log('groupUpdateResult:', groupUpdateResult);

                            if (groupUpdateResult && groupUpdateResult.affectedRows === 1) {
                                // Fetch the updated GroupMem row
                                db.query('SELECT * FROM GroupMem WHERE GroupID = ?', [availableGroupId], (err, updatedGroupResult) => {
                                    if (err) {
                                        console.error('Error fetching updated group details:', err);
                                        return res.status(500).json({ message: 'Internal Server Error' });
                                    }

                                    const updatedGroup = updatedGroupResult[0];

                                    console.log('Updated GroupMem:', updatedGroup);

                                    if (updatedGroup && updatedGroup.MemberCount !== undefined && updatedGroup.MemberCount >= 3) {
                                        console.log('Group is full. MemberCount:', updatedGroup.MemberCount);

                                        // Update group to be active
                                        db.query('UPDATE GroupMem SET IsActive = 1 WHERE GroupID = ?', [availableGroupId], (err, activateResult) => {
                                            if (err) {
                                                console.error('Error activating the group:', err);
                                                return res.status(500).json({ message: 'Internal Server Error' });
                                            }

                                            console.log('Group activated successfully');

                                            return res.status(200).json({ message: 'User added to an available group, and the group is now active' });
                                        });
                                    } else {
                                        console.log('Group is not full or MemberCount is undefined. MemberCount:', updatedGroup && updatedGroup.MemberCount);

                                        return res.status(200).json({ message: 'User added to an available group' });
                                    }
                                });
                            } else {
                                console.log('Group update failed or no rows affected');

                                return res.status(500).json({ message: 'Internal Server Error' });
                            }


                        });
                    });
                }
            });
        } else {
            return res.status(200).json({ message: 'User is already active in a group' });
        }
    });
    });
    function hello(){

    }
});

        
  
}