USE hasan;
-- Drop tables if they exist
DROP TABLE IF EXISTS `users`;
DROP TABLE IF EXISTS `groupmem`;
DROP TABLE IF EXISTS `temp_users`;

-- Create groupmem table
CREATE TABLE IF NOT EXISTS `groupmem` (
  `GroupID` INT NOT NULL AUTO_INCREMENT,
  `Membership` VARCHAR(50) NULL DEFAULT NULL,
  `IsActive` TINYINT(1) NULL DEFAULT NULL,
  `MemberCount` INT NULL DEFAULT NULL,
  `TotalAmount` INT NULL DEFAULT '0',
  `Months` INT NULL DEFAULT '0',
  PRIMARY KEY (`GroupID`)
) ENGINE = InnoDB
AUTO_INCREMENT = 1
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;


-- Create users table
CREATE TABLE IF NOT EXISTS `users` (
  `user_id` INT NOT NULL AUTO_INCREMENT,
  `first_name` VARCHAR(45) NOT NULL,
  `last_name` VARCHAR(45) NOT NULL,
  `email` VARCHAR(45) NOT NULL,
  `password` VARCHAR(100) NOT NULL,
  `Membership` VARCHAR(50) NULL DEFAULT NULL,
  `IsActive` TINYINT(1) NULL DEFAULT '0',
  `GroupID` INT NULL DEFAULT NULL,
  `RandomNumber` INT NULL DEFAULT NULL,
  `hasPaid` TINYINT(1) NULL DEFAULT '0',
  `hasReceived` TINYINT(1) NULL DEFAULT '0',
  `amount` INT NULL DEFAULT '0',
  `monthly_salary` VARCHAR(50) NULL DEFAULT NULL,
  `verification_token` VARCHAR(100) NULL DEFAULT NULL,
  `verified` TINYINT(1) NULL DEFAULT '0',
  `eligible` TINYINT NULL DEFAULT '0',
  PRIMARY KEY (`user_id`),
  UNIQUE INDEX `user_id_UNIQUE` (`user_id` ASC) VISIBLE,
  UNIQUE INDEX `email_UNIQUE` (`email` ASC) VISIBLE,
  INDEX `GroupID` (`GroupID` ASC) VISIBLE,
  CONSTRAINT `users_ibfk_1`
    FOREIGN KEY (`GroupID`)
    REFERENCES `groupmem` (`GroupID`)
) ENGINE = InnoDB
AUTO_INCREMENT = 1
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;


-- Create temp_users table
CREATE TABLE IF NOT EXISTS `temp_users` (
  `user_id` INT NOT NULL AUTO_INCREMENT,
  `first_name` VARCHAR(45) NOT NULL,
  `last_name` VARCHAR(45) NOT NULL,
  `email` VARCHAR(45) NOT NULL,
  `password` VARCHAR(100) NOT NULL,
  `verification_token` VARCHAR(100) NULL DEFAULT NULL,
  `verified` TINYINT(1) NULL DEFAULT '0',
  PRIMARY KEY (`user_id`),
  UNIQUE INDEX `user_id_UNIQUE` (`user_id` ASC) VISIBLE,
  UNIQUE INDEX `email_UNIQUE` (`email` ASC) VISIBLE
) ENGINE = InnoDB
AUTO_INCREMENT = 1
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;
