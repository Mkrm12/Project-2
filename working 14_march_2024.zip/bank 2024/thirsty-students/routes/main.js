const nodemailer = require('nodemailer');
const crypto = require('crypto');

const multer = require('multer');
const pdfParse = require('pdf-parse'); // Use pdfParse instead of PDFParser
const fs = require('fs');


const PUBLISHABLE_KEY =
    "pk_test_51OpBS7JwdmEZr0TBHqCchDaMi6PYLgAgOwpqYpyhIquyhVtN0N5eE5VEoaQJp1EyAkFQEYVRpet0rxWkiHQdmD4I00qxmMtRY9";
const SECRET_KEY =
    "sk_test_51OpBS7JwdmEZr0TBnsNmUzGRcRDfEtzZBMRAnaS2uQGVUFv9s91GgTmwzDJl0RbeI5YFD9ecjOpaZC285cEtJbCY00lqnQfEby";
const stripe = require("stripe")(SECRET_KEY);


const storage = multer.memoryStorage(); // Use memory storage for file uploads
const upload = multer({
    storage: storage
});

module.exports = function (app, forumData) {
    const bcrypt = require('bcrypt');
    const saltRounds = 10;
    const MIN_CREDIT_SCORE = 100;
    const MAX_CREDIT_SCORE = 1000;

    app.get("/", (req, res) => {
        res.render("index.ejs");
    });

    app.get("/how-It-works", (req, res) => {
        res.render("howItworks.ejs");
    });
    app.get("/contact", (req, res) => {
        res.render("contactUs.ejs");
    });

    app.get("/register", (req, res) => {
        res.render("register.ejs");
    });
    app.get("/login", (req, res) => {
        res.render("login.ejs");
    });

    app.get("/Paymentpage", (req, res) => {
        const selectedPackageAmount = req.query.selectedPackageAmount;

        // Render the Paymentpage.ejs template and pass the selectedPackageAmount variable
        res.render("Paymentpage.ejs", {
            key: PUBLISHABLE_KEY,
            selectedPackageAmount: selectedPackageAmount,
        });
    });
    app.post("/payment", (req, res) => {
        const userId = req.session.userID;

        // Fetch user details from the database
        db.query(
            "SELECT first_name, last_name, Membership FROM users WHERE user_id = ?",
            [userId],
            function (err, result) {
                if (err) {
                    console.error("Error fetching user details:", err);
                    return res.status(500).send("Internal Server Error");
                }

                const user = result[0];
                const userName = user.first_name;
                const selectedPackageAmount = user.Membership;
                console.log(selectedPackageAmount);
                // creating the groups 

                if (!userId) {
                    return res.status(401).json({
                        message: 'Unauthorized'
                    });
                }

                if (user.hasPaid === 1) {
                    res.render('payment-successful.ejs')
                } else {

                    // Create a customer in Stripe with user's email and name
                    stripe.customers
                        .create({
                            email: req.body.stripeEmail,
                            source: req.body.stripeToken,
                            name: userName,
                        })
                        .then((customer) => {
                            // Create a charge in Stripe
                            return stripe.charges.create({
                                amount: selectedPackageAmount * 10,
                                description: "Hasan package",
                                currency: "GBP",
                                customer: customer.id,
                            });
                        })
                        .then((charge) => {
                            console.log("this pacakge" + selectedPackageAmount);

                            // Update hasPaid in the users table to 1
                            db.query(
                                "UPDATE users SET hasPaid = 1 WHERE user_id = ?",
                                [userId],
                                function (updateErr, updateResult) {
                                    if (updateErr) {
                                        console.error("Error updating hasPaid:", updateErr);
                                        return res.status(500).send("Internal Server Error");
                                    }

                                    // Update the amount column in the users table
                                    db.query(
                                        "UPDATE users SET amount = amount - ? WHERE user_id = ?",
                                        [selectedPackageAmount / 10, userId],
                                        function (amountUpdateErr, amountUpdateResult) {
                                            if (amountUpdateErr) {
                                                console.error("Error updating amount:", amountUpdateErr);
                                                return res.status(500).send("Internal Server Error");
                                            }
                                            db.query(
                                                "SELECT GroupID FROM users WHERE user_id = ?",
                                                [userId], // Assuming userId is the user_id of the user
                                                function (groupErr, groupResult) {
                                                    if (groupErr) {
                                                        console.error("Error retrieving GroupID:", groupErr);
                                                        return res.status(500).send("Internal Server Error");
                                                    }

                                                    const groupId = groupResult[0].GroupID;
                                                    console.log("GroupID:", groupId);

                                                    // Update the TotalAmount column in the groupmem table
                                                    db.query(
                                                        "UPDATE groupmem SET TotalAmount = TotalAmount + ? WHERE GroupID = ?",
                                                        [selectedPackageAmount / 10, groupId],
                                                        function (totalAmountUpdateErr, totalAmountUpdateResult) {
                                                            if (totalAmountUpdateErr) {
                                                                console.error("Error updating TotalAmount:", totalAmountUpdateErr);
                                                                return res.status(500).send("Internal Server Error");
                                                            }
                                                            console.log("total amount:", totalAmountUpdateResult);


                                                            // Check if all users in the group have paid
                                                            db.query(
                                                                "SELECT COUNT(*) AS paidCount FROM users JOIN groupmem ON users.GroupID = groupmem.GroupID WHERE users.GroupID = ? AND users.hasPaid = 1 AND groupmem.IsActive = 1",
                                                                [groupId],
                                                                function (countErr, countResult) {
                                                                    if (countErr) {
                                                                        console.error("Error counting unpaid users:", countErr);
                                                                        return res.status(500).send("Internal Server Error");
                                                                    }

                                                                    const paidCount = countResult[0].paidCount;
                                                                    console.log("Number of has Paid:" + countResult);
                                                                    console.log("Number of has Paid:" + countResult[0]);


                                                                    console.log("Number of has Paid:" + paidCount);
                                                                    console.log("Number of has Paid:" + groupId);

                                                                    if (paidCount === 3) {
                                                                        // All users in the group have paid
                                                                        console.log("All users in the group have paid")
                                                                        // Increment Months in groupmem table
                                                                        db.query(
                                                                            "UPDATE groupmem SET Months = Months + 1 WHERE GroupID = ?",
                                                                            [groupId],
                                                                            function (updateMonthsErr, updateMonthsResult) {
                                                                                console.log("Number of has :" + groupId);

                                                                                if (updateMonthsErr) {
                                                                                    console.error("Error updating Months:", updateMonthsErr);
                                                                                }


                                                                                // Fetch TotalAmount from groupmem
                                                                                console.log("next")

                                                                                db.query(
                                                                                    "SELECT TotalAmount FROM groupmem WHERE GroupID = ?",
                                                                                    [groupId],
                                                                                    function (totalAmountErr, totalAmountResult) {
                                                                                        if (totalAmountErr) {
                                                                                            console.error("Error fetching TotalAmount:", totalAmountErr);
                                                                                            return res.status(500).send("Internal Server Error");
                                                                                        }
                                                                                        console.log("working")
                                                                                        if (totalAmountResult.length === 0) {
                                                                                            console.error("No TotalAmount found for GroupID:", groupId);
                                                                                            return res.status(404).send("TotalAmount not found");
                                                                                        }

                                                                                        console.log("TotalAmount Result:", totalAmountResult);

                                                                                        console.log(totalAmountResult)
                                                                                        console.log(totalAmountResult[0])
                                                                                        console.log(totalAmountResult[0].TotalAmount)


                                                                                        const totalAmount = totalAmountResult[0].TotalAmount;
                                                                                        console.log(totalAmount)


                                                                                        // Update amount in users table
                                                                                        db.query(
                                                                                            "UPDATE users JOIN groupmem ON users.GroupID = groupmem.GroupID SET users.amount = users.amount + ? WHERE groupmem.Months = users.RandomNumber",
                                                                                            [totalAmount],
                                                                                            function (updateAmountErr, updateAmountResult) {
                                                                                                if (updateAmountErr) {
                                                                                                    console.error("Error updating user amount:", updateAmountErr);
                                                                                                    return res.status(500).send("Internal Server Error");
                                                                                                }

                                                                                                return res.render('payment-successful.ejs');
                                                                                            }
                                                                                        );
                                                                                        console.log("not working")

                                                                                        // Update the hasPaid flag for all users in the group
                                                                                        db.query(
                                                                                            "UPDATE users SET hasPaid = 0 WHERE GroupID = ?",
                                                                                            [groupId],
                                                                                            function (resetHasPaidErr, resetHasPaidResult) {
                                                                                                if (resetHasPaidErr) {
                                                                                                    console.error("Error resetting hasPaid flag:", resetHasPaidErr);
                                                                                                    return res.status(500).send("Internal Server Error");
                                                                                                }

                                                                                                // Reset TotalAmount in groupmem to 0
                                                                                                db.query(
                                                                                                    "UPDATE groupmem SET TotalAmount = 0 WHERE GroupID = ?",
                                                                                                    [groupId],
                                                                                                    function (resetTotalAmountErr, resetTotalAmountResult) {
                                                                                                        if (resetTotalAmountErr) {
                                                                                                            console.error("Error resetting TotalAmount:", resetTotalAmountErr);
                                                                                                            return res.status(500).send("Internal Server Error");
                                                                                                        }

                                                                                                        return res.render('payment-successful.ejs');
                                                                                                    }
                                                                                                );
                                                                                            }
                                                                                        );
                                                                                    }
                                                                                )
                                                                            });


                                                                        console.log("Month updated")
                                                                    } else {
                                                                        // Not all users in the group have paid yet
                                                                        return res.render('payment-successful.ejs');
                                                                    }
                                                                }
                                                            );
                                                        }
                                                    )
                                                }


                                            );
                                        }
                                    );
                                }
                            );
                        })
                }


                // Retrieve user details
                db.query('SELECT * FROM users WHERE user_id = ?', [userId], (err, results) => {
                    if (err) {
                        console.error('Error retrieving user details:', err);
                        return res.status(500).json({
                            message: 'Internal Server Error'
                        });
                    }

                    if (results.length === 0) {
                        return res.status(404).json({
                            message: 'User not found'
                        });
                    }

                    const user = results[0];

                    // Check if the user is not active
                    if (user.IsActive === 0) {
                        // Find a group with IsActive = 0, matching membership, and MemberCount < 3
                        db.query('SELECT * FROM GroupMem WHERE IsActive = 0 AND Membership = ? AND MemberCount < 3 LIMIT 1', [user.Membership], (err, groupResults) => {
                            if (err) {
                                console.error('Error checking available groups:', err);
                                return res.status(500).json({
                                    message: 'Internal Server Error'
                                });
                            }

                            if (groupResults.length === 0) {
                                // No available groups, create a new group
                                db.query('INSERT INTO GroupMem (Membership, IsActive, MemberCount) VALUES (?, 0, 1)', [user.Membership], (err, insertResult) => {
                                    if (err) {
                                        console.error('Error creating a new group:', err);
                                        return res.status(500).json({
                                            message: 'Internal Server Error'
                                        });
                                    }

                                    const newGroupId = insertResult.insertId;

                                    // Update user details with the new group ID
                                    db.query('UPDATE users SET IsActive = 1, GroupID = ? WHERE user_id = ?', [newGroupId, userId], (err, updateResult) => {
                                        if (err) {
                                            console.error('Error updating user details with a new group:', err);
                                            return res.status(500).json({
                                                message: 'Internal Server Error'
                                            });
                                        }

                                        const message = 'User added to a new group';
                                        res.render('messagePage', {
                                            message
                                        });
                                        // return res.status(200).json({ message: 'User added to a new group' });
                                    });
                                });
                            } else {
                                // Found an available group, add user to the group
                                const availableGroupId = groupResults[0].GroupID;

                                // Update user details with the available group ID
                                db.query('UPDATE users SET IsActive = 1, GroupID = ? WHERE user_id = ?', [availableGroupId, userId], (err, updateResult) => {
                                    if (err) {
                                        console.error('Error updating user details with an available group:', err);
                                        return res.status(500).json({
                                            message: 'Internal Server Error'
                                        });
                                    }

                                    // Update MemberCount in GroupMem
                                    db.query('UPDATE GroupMem SET MemberCount = MemberCount + 1 WHERE GroupID = ?', [availableGroupId], (err, groupUpdateResult) => {
                                        if (err) {
                                            console.error('Error updating group member count:', err);
                                            return res.status(500).json({
                                                message: 'Internal Server Error'
                                            });
                                        }

                                        // Check if the group is now full
                                        console.log('groupUpdateResult:', groupUpdateResult);

                                        if (groupUpdateResult && groupUpdateResult.affectedRows === 1) {
                                            // Fetch the updated GroupMem row
                                            db.query('SELECT * FROM GroupMem WHERE GroupID = ?', [availableGroupId], (err, updatedGroupResult) => {
                                                if (err) {
                                                    console.error('Error fetching updated group details:', err);
                                                    return res.status(500).json({
                                                        message: 'Internal Server Error'
                                                    });
                                                }

                                                const updatedGroup = updatedGroupResult[0];

                                                console.log('Updated GroupMem:', updatedGroup);

                                                if (updatedGroup.MemberCount >= 3) {
                                                    console.log('Group is full. MemberCount:', updatedGroup.MemberCount);

                                                    // Update group to be active
                                                    db.query('UPDATE GroupMem SET IsActive = 1 WHERE GroupID = ?', [availableGroupId], (err, activateResult) => {
                                                        if (err) {
                                                            console.error('Error activating the group:', err);
                                                            return res.status(500).json({
                                                                message: 'Internal Server Error'
                                                            });
                                                        }

                                                        console.log('Group activated successfully');
                                                        assignRandomNumbersToGroupMembers(availableGroupId);

                                                        console.log('Random numbers assigned successfully');

                                                        const message = 'User added to an available group, and the group is now active';
                                                        res.render('messagePage', {
                                                            message
                                                        });
                                                    });


                                                } else {
                                                    console.log('Group is not full or MemberCount is undefined. MemberCount:', updatedGroup && updatedGroup.MemberCount);
                                                    const message = 'User added to an available group';
                                                    res.render('messagePage', {
                                                        message
                                                    });
                                                }
                                            });
                                        } else {
                                            console.log('Group update failed or no rows affected');

                                            return res.status(500).json({
                                                message: 'Internal Server Error'
                                            });
                                        }


                                    });
                                });
                            }
                        });
                    }
                });
            });


    });




    app.get("/setting", (req, res) => {
        res.render("settings.ejs");
    });
    app.get("/eligibility", (req, res) => {
        const userId = req.session.userID;

        // Check eligibility status in the database
        db.query('SELECT * FROM users WHERE user_id = ?', [userId], function (err, results) {
            if (err) {
                console.error('Error checking eligibility status:', err);
                return res.status(500).send('Internal Server Error');
            }

            const user = results[0];
            if (!user) {
                // User not found, handle accordingly
                return res.status(400).send('User not found');
            }

            const selectedPackageAmount = user.Membership;

            console.log("User has paid: " + user.hasPaid)

            if (user.eligible === 0) {
                // Eligibility is 0, redirect to activate my account page
                return res.render('eligibility.ejs');
            } else if (user.Membership === "0") {
                // Eligibility is 1, render the package page
                res.render('initialpackage.ejs');
            } else if (user.hasPaid === 0) {
                res.render("Paymentpage.ejs", {
                    key: PUBLISHABLE_KEY,
                    selectedPackageAmount: selectedPackageAmount,
                });
            } else {
                return res.redirect('/start');

            }
        });
    });

    // Handle file upload
    app.post('/upload-pdf', upload.single('pdfFile'), function (req, res) {
        // Process the uploaded file

        // Check if a file has already been uploaded for this user
        const userId = req.session.userId; /* Obtain user ID (you may use session or other authentication mechanism) */ ;
        // if (fileUploadStates.get(userId)) {
        //     // User has already uploaded a file, handle accordingly (e.g., show an error message)
        //     return res.render('activate-account.ejs', { fileUploaded: false, alreadyUploaded: true });
        // }

        if (req.file) {
            // Generate a random credit score
            const creditScore = Math.floor(Math.random() * (MAX_CREDIT_SCORE - MIN_CREDIT_SCORE + 1)) + MIN_CREDIT_SCORE;
            console.log("Credit Score:", creditScore);

            // Set file upload state to true for this user
            // fileUploadStates.set(userId, true);

            // Calculate eligibility based on credit score
            let eligibilityMessage = '';

            //Check eligibility based on credit score
            if (creditScore >= 100 && creditScore <= 500) {
                eligibilityMessage = "We're sorry, you are not eligible.";
            } else if (creditScore > 500 && creditScore <= 1000) {
                eligibilityMessage = "Congratulations, you are eligible.";
                const userId = req.session.userID;


                // Update user eligibility
                db.query(
                    'UPDATE users SET eligible = 1 WHERE user_id = ?',
                    [userId],
                    function (err, result) {
                        console.log("Eligibile " + userId)
                        if (err) {
                            console.error('Error updating user eligibility:', err);
                            return res.status(500).send('Internal Server Error');
                        }

                        console.log('Eligibility updated');
                        // Render the activate-account page with file upload success message and credit score
                        //res.render('activate-account.ejs', { fileUploaded: true, alreadyUploaded: false, eligibilityMessage: eligibilityMessage || '' });
                        res.render('initialpackage.ejs');
                    }
                );
                return; // Return to avoid rendering the page multiple times
            }

            // Render the activate-account page with file upload success message and credit score
            res.render('eligibility.ejs', {
                fileUploaded: true,
                alreadyUploaded: false,
                eligibilityMessage: eligibilityMessage || ''
            });
        }
    });
    app.get("/change-package", (req, res) => {
        res.render("packages.ejs");
    });

    app.post("/change-package", (req, res) => {
        const {
            amount
        } = req.body;
        const userId = req.session.userID;
        // Ensure both amount and userId are available
        if (!amount || !userId) {
            return res.status(400).json({
                message: 'Amount and user ID are required'
            });
        }

        const updateQuery = "UPDATE users SET membership = ? WHERE user_id = ? AND IsActive = 0";

        // Assuming you have a database connection pool or similar mechanism
        // Execute the query using your database library
        db.query(updateQuery, [amount, userId], (err, result) => {
            if (err) {
                console.error('Error updating membership:', err);
                return res.status(500).json({
                    message: 'Internal Server Error'
                });
            }

            // Check if a row was affected (indicating a successful update)
            if (result.affectedRows > 0) {
                // Handle successful update, if needed
                const message = 'Membership updated successfully';
                res.render('messagePage', {
                    message
                });
            } else {
                // No rows were affected, meaning the user might not exist or IsActive is not 0
                const message = 'Unable to update membership. User is active.';
                res.render('messagePage', {
                    message
                });
            }
        });
    });


    app.get("/forgot-password", (req, res) => {
        res.render("forgot-password.ejs");
    });

    // Handle GET request for reset-password
    app.get('/reset-password/:token', function (req, res) {
        const token = req.params.token;
        console.log('Token from URL:', token);

        // Render the reset-password.ejs page with the token
        res.render('reset-password.ejs', {
            token
        });
    });

    app.get("/dashboard", (req, res) => {
        res.render("dashboard.ejs");
    });

    app.post("/register", (req, res) => {
        const {
            first_name,
            last_name,
            email,
            password
        } = req.body;

        // Generate a unique verification token
        const verificationToken = crypto.randomBytes(20).toString('hex');

        // Hash the password before storing it in the temporary table
        bcrypt.hash(password, saltRounds, function (err, hashedPassword) {
            if (err) {
                console.error('Error hashing password:', err);
                return res.status(500).send('Internal Server Error');
            }


            // Save the user data along with the verification token in a temporary table
            db.query(
                'INSERT INTO temp_users (first_name, last_name, email, password, verification_token) VALUES (?, ?, ?, ?, ?)',
                [first_name, last_name, email, hashedPassword, verificationToken],
                function (err, result) {
                    if (err) {
                        console.error('Error inserting user into temp_users:', err);
                        return res.status(500).send('Internal Server Error');
                    }

                    // Send verification email
                    sendVerificationEmail(email, verificationToken);

                    console.log('Verification email sent successfully');
                    res.redirect('/login'); // Redirect to login page after signup
                }
            );
        });
    });

    // Verification endpoint
    app.get('/verify/:token', function (req, res) {
        const token = req.params.token;

        // Find user by verification token in the temporary table
        db.query('SELECT * FROM temp_users WHERE verification_token = ?', [token], function (err, results) {
            if (err) {
                console.error('Error checking verification token:', err);
                return res.status(500).send('Internal Server Error');
            }

            if (results.length === 0) {
                return res.status(400).send('Invalid verification token');
            }

            // Move user data from temporary table to actual users table
            const user = results[0];

            // Generate a random number between 500 and 10000 for monthly salary
            const monthlySalary = Math.floor(Math.random() * (10000 - 500 + 1)) + 500;

            db.query('INSERT INTO users (first_name, last_name, email, password,Membership, monthly_salary) VALUES (?, ?, ?, ?,0,?)',
                [user.first_name, user.last_name, user.email, user.password, monthlySalary],
                function (err, result) {
                    if (err) {
                        console.error('Error moving user data to users table:', err);
                        return res.status(500).send('Internal Server Error');
                    }

                    // Update user status to verified
                    const userId = result.insertId;
                    db.query('UPDATE users SET verification_token = NULL, verified = 1 WHERE user_id = ?', [userId], function (err, result) {
                        if (err) {
                            console.error('Error updating user verification status:', err);
                            return res.status(500).send('Internal Server Error');
                        }
                        console.log('User verified and data moved successfully');
                        res.send('Verification successful. You can now log in.');
                    });
                });
        });
    });

    // Function to send verification email
    function sendVerificationEmail(toEmail, token) {
        const transporter = nodemailer.createTransport({
            service: 'gmail',
            auth: {
                user: 'areebshahzad0052@gmail.com',
                pass: 'ovgi otlx eknk pqdg'
            }
        });

        const mailOptions = {
            from: 'areebshahzad0052@gmail.com',
            to: toEmail,
            subject: 'Email Verification',
            text: `Click the following link to verify your email: http://localhost:8000/verify/${token}`
        };

        transporter.sendMail(mailOptions, function (error, info) {
            if (error) {
                console.error('Error sending verification email:', error);
            } else {
                console.log('Email sent:', info.response);
            }
        });
    }

    // Login 

    app.post('/login', (req, res) => {
        const {
            email,
            password
        } = req.body;

        // Check if email and password are provided
        if (!email || !password) {
            return res.status(400).render('login.ejs', {
                emailError: 'Email and password are required',
                passwordError: ''
            });
        }

        // Check if email exists in the database
        db.query('SELECT * FROM users WHERE email = ?', [email], function (err, results) {
            if (err) {
                console.error('Error checking email:', err);
                return res.status(500).send('Internal Server Error');
            }

            // If email does not exist, set error message
            if (results.length === 0) {
                return res.status(400).render('login.ejs', {
                    emailError: 'Email not registered',
                    passwordError: ''
                });
            }

            const user = results[0];

            // Check if the provided password matches the hashed password in the database
            bcrypt.compare(password, user.password, function (err, passwordMatch) {
                console.log('Password Match:', passwordMatch);
                if (err) {
                    console.error('Error comparing passwords:', err);
                    return res.status(500).send('Internal Server Error');
                }

                // If passwords match, login successful
                if (passwordMatch) {

                    // Store user ID in the session
                    req.session.userID = user.user_id;

                    // Log the user ID to the console
                    console.log('User ID:', req.session.userID);
                    res.render('dashboard.ejs');

                } else {
                    // If passwords don't match, set error message
                    res.status(400).render('login.ejs', {
                        emailError: '',
                        passwordError: 'Incorrect Email or Password'
                    });
                }
            });
        });
    });
    app.get('/logout', (req, res) => {
        req.session.destroy((err) => {
            if (err) {
                console.error('Error destroying session:', err);
            }
            res.redirect('/');
        });
    });


    // Handle POST request for forgot-password
    app.post('/forgot-password', function (req, res) {
        const {
            email
        } = req.body;

        // Check if email exists in the users table
        db.query('SELECT * FROM users WHERE email = ?', [email], function (err, results) {
            if (err) {
                console.error('Error checking email for forgot password:', err);
                return res.status(500).send('Internal Server Error');
            }

            if (results.length === 0) {
                return res.status(400).send('Email not found');
            }

            // Generate a unique verification token
            const verificationToken = crypto.randomBytes(20).toString('hex');

            // Save the verification token in the database
            db.query(
                'UPDATE users SET verification_token = ? WHERE email = ?',
                [verificationToken, email],
                function (err, result) {
                    console.log('Update result:', result);
                    if (err) {
                        console.error('Error updating verification token:', err);
                        return res.status(500).send('Internal Server Error');
                    }

                    // Send email with password reset link
                    sendPasswordResetEmail(email, verificationToken);

                    console.log('Password reset email sent successfully');
                    res.send('Password reset email sent. Check your email for instructions.');
                }
            );
        });
    });

    // Function to send password reset email
    function sendPasswordResetEmail(toEmail, token) {
        const resetLink = `http://localhost:8000/reset-password/${token}`;

        const transporter = nodemailer.createTransport({
            service: 'gmail',
            auth: {
                user: 'areebshahzad0052@gmail.com',
                pass: 'ovgi otlx eknk pqdg'
            }
        });

        const mailOptions = {
            from: 'areebshahzad0052@gmail.com',
            to: toEmail,
            subject: 'Password Reset',
            text: `Click the following link to reset your password: http://localhost:8000/reset-password/${token}`
        };


        transporter.sendMail(mailOptions, function (error, info) {
            if (error) {
                console.error('Error sending password reset email:', error);
            } else {
                console.log('Password reset email sent:', info.response);
            }
        });
    }



    // Handle POST request for reset-password
    app.post('/reset-password', function (req, res) {
        const token = req.body.token; // Retrieve the token from the form submission
        const {
            newPassword,
            confirmNewPassword
        } = req.body;

        // Find user by verification token
        db.query('SELECT * FROM users WHERE verification_token = ?', [token], function (err, results) {
            if (err) {
                console.error('Error checking verification token for password reset:', err);
                return res.status(500).send('Internal Server Error');
            }

            if (results.length === 0) {
                return res.status(400).send('Invalid verification token');
            }

            const user = results[0];

            // Check if passwords match
            if (newPassword !== confirmNewPassword) {
                return res.status(400).send('Passwords do not match');
            }

            // Check if newPassword is not empty
            if (!newPassword) {
                return res.status(400).send('New password cannot be empty');
            }

            // Hash the new password
            bcrypt.hash(newPassword, saltRounds, function (err, hashedPassword) {
                if (err) {
                    console.error('Error hashing new password:', err);
                    return res.status(500).send('Internal Server Error');
                }

                // Update user password and clear verification token
                db.query(
                    'UPDATE users SET password = ?, verification_token = NULL WHERE user_id = ?',
                    [hashedPassword, user.user_id],

                    function (err, result) {
                        if (err) {
                            console.error("Problem updating database")
                            console.error('Error updating user password:', err);
                            return res.status(500).send('Internal Server Error');
                        }

                        console.log('Password reset successful');
                        res.send('Password reset successful. You can now log in.');
                    }
                );
            });
        });
    });
    // Display start or start-info based on user's isActive status
    app.get('/start', function (req, res) {
        const userId = req.session.userID;

        // Check if the user is active
        db.query('SELECT IsActive FROM users WHERE user_id = ?', [userId], (error, result) => {
            if (error) {
                console.error('Error checking user status:', error);
                return res.status(500).json({
                    message: 'Internal Server Error'
                });
            }

            const isActive = result[0] ? result[0].IsActive : null;
            console.log(isActive)
            if (isActive === 0) {
                // User is not active, render start.ejs
                res.render('start.ejs');
            } else if (isActive === 1) {
                const userId = req.session.userID;

                // User is active, render start-info.ejs
                const sqlquery = `
            SELECT
                GroupMem.GroupID as id,
                GroupMem.Membership as name,
                GroupMem.MemberCount as memberCount
            FROM GroupMem
            LEFT JOIN users ON GroupMem.GroupID = users.GroupID
            WHERE users.user_id = ?;

            `;
                db.query(sqlquery, [userId], (error, result) => {
                    if (error) {
                        console.error('Error fetching user-related group data:', error);
                        return res.status(500).json({
                            message: 'Internal Server Error'
                        });
                    }

                    const userData = result[0];

                    if (!userData) {
                        return res.status(404).json({
                            message: 'User not found in any group'
                        });
                    }

                    // Render start-info.ejs with relevant user-related data
                    res.render('start-info.ejs', {
                        userData
                    });
                });
            } else {
                // Handle other cases if needed
                return res.status(404).json({
                    message: 'User status unknown'
                });
            }
        });
    });


    // Function to assign random numbers to group members
    function assignRandomNumbersToGroupMembers(groupId) {
        // Query to get group members from users table
        db.query('SELECT user_id FROM users WHERE GroupID = ?', [groupId], (selectMembersErr, members) => {

            // Generate unique random numbers for each member
            const uniqueRandomNumbers = generateUniqueRandomNumbers(members.length);

            // Update each user in the group with their assigned random number
            members.forEach((member, index) => {
                const randomNum = uniqueRandomNumbers[index];
                db.query('UPDATE users SET RandomNumber = ? WHERE user_id = ?', [randomNum, member.user_id], (updateErr, updateResult) => {

                });
            });

        });
    }

    // Function to generate unique random numbers
    function generateUniqueRandomNumbers(count) {
        const numbers = Array.from({
            length: count
        }, (_, index) => index + 1);
        for (let i = numbers.length - 1; i > 0; i--) {
            const j = Math.floor(Math.random() * (i + 1));
            [numbers[i], numbers[j]] = [numbers[j], numbers[i]];
        }
        return numbers;
    }

}