document.addEventListener('DOMContentLoaded', function() {
  const toggleButton = document.getElementById('darkModeToggle');
  toggleButton.addEventListener('click', function() {
    document.body.classList.toggle('dark-mode');
    toggleButton.textContent = document.body.classList.contains('dark-mode') ? 'Dark Mode ON' : 'Light Mode ON';
  });
});