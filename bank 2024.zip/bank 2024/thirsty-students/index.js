// Import the modules we need
var mysql = require('mysql');
var express = require('express')
var ejs = require('ejs')
var bodyParser = require('body-parser')



// Define the database connection
const db = mysql.createConnection({
    host: 'localhost',
    user: 'appuser',
    password: 'app2027',
    database: 'hasan'
});
// Connect to the database
db.connect((err) => {
    if (err) {
        throw err;
    }
    console.log('Connected to database');
});
global.db = db;


// Create the express application object
const app = express()
const port = 8000
app.use(bodyParser.urlencoded({
    extended: true
}))

// Set up css
app.use(express.static(__dirname + '/public'));

app.set("views", __dirname + "/views");
app.set("view engine", "ejs");
app.engine("html", ejs.renderFile);

app.get("/", (req, res) => {
  res.render("index.ejs");
});

app.get("/how-It-works", (req, res) => {
  res.render("howItworks.ejs");
});
app.get("/contact", (req, res) => {
  res.render("contactUs.ejs");
});

app.get("/register", (req, res) => {
  res.render("register.ejs");
});
app.get("/login", (req, res) => {
  res.render("login.ejs");
});
app.post('/login', (req, res) => {

  res.redirect('/dashboard');
});

app.get("/dashboard", (req, res) => {
  res.render("dashboard.ejs");
});

app.post("/register", (req, res) => {
  // Saving data in the database would typically happen here
  res.send(
    `Hello ${req.body.first} ${req.body.last}, you are now registered! We will be sending an email to you at ${req.body.email}`
  );
});

app.listen(port, () => console.log(`App listening on port ${port}!`));
